package Utils;
public interface Reader {
    String readText();
    String readLine();
}
