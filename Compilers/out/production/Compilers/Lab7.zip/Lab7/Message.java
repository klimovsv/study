package Lab7;

public class Message {

    boolean isError;
    String text;

    public Message(boolean isError, String text) {
        this.isError = isError;
        this.text = text;
    }
}
